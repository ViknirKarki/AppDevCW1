﻿using System;
namespace AppDevCW1.Data
{
    public class Coffees
    {
        public int ID { get; set; }
        public string CoffeesName { get; set; }
        public int CoffeesPrice { get; set; }
    }
}