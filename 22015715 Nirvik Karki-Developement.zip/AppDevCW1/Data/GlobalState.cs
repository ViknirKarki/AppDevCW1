﻿using AppDevCW1.Data;

namespace AppDevCW1.Data;

public class GlobalState
{
    public User CurrentUser { get; set; }
}