﻿using System;
namespace AppDevCW1.Data
{
    public class AddIns
    {
        public AddIns()
        {
        }
        public int ID { get; set; }
        public string AddInName { get; set; }
        public int AddInPrice { get; set; }
    }
}