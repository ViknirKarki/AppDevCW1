﻿namespace AppDevCW1.Data;

public enum Role
{
    User, Admin
}